console.log('apple')
// goodideas-studio 字串反轉
		const str = 'goodideas-studio';
const word = str.split('');   
console.log('str:',str);
console.log('word',word);